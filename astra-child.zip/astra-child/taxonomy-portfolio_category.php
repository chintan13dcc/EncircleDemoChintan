<?php

get_header();
?>
<div class="title-wrap">
   <h1> <?php echo get_the_archive_title(); ?></h1>
</div>
<main id="main" class="content-wrapper">
   <div class="posts-section">
      <?php if (have_posts()) { ?>
         <div class="archived-posts">
            <?php while (have_posts()) {
               the_post(); ?>
               <div class="archive-item">
                  <?php if (has_post_thumbnail(get_the_ID())) { ?>
                     <div class="top-section">
                        <div class="portfolio-thumbnail">
                           <a href="<?php the_permalink(); ?>">
                              <?php the_post_thumbnail('large'); ?>
                           </a>
                        </div>
                     </div>
                  <?php } ?>
                  <div class="bottom-section">
                     <div class="portfolio-title">
                        <a href="<?php the_permalink(); ?>">
                           <h3><?php the_title(); ?></h3>
                        </a>
                     </div>

                     <div class="read-more">
                        <a href="<?php the_permalink(); ?>">Read More <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048">
                              <path d="M6.125 1088h1797.89l-402.976 403 89.994 90L2048 1024l-556.966-557-89.994 90 402.976 403H6.125v128z"></path>
                           </svg></a>
                     </div>
                  </div>
               </div>
            <?php } ?>
         </div>
      <?php wp_reset_postdata();
      } else { ?>
         <div class="archived-posts"><?php echo esc_html__('No posts matching the query were found.', 'your-translate-domain'); ?></div>
      <?php } ?>
   </div>
</main>

<?php
get_footer();
?>