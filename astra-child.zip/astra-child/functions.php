<?php

/**
 * Astra Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Astra Child
 * @since 1.0.0
 */

/**
 * Define Constants
 */
define('CHILD_THEME_ASTRA_CHILD_VERSION', '1.0.0');

/**
 * Enqueue styles
 */
function child_enqueue_styles()
{

	wp_enqueue_style('astra-child-theme-css', get_stylesheet_directory_uri() . '/style.css', array('astra-theme-css'), CHILD_THEME_ASTRA_CHILD_VERSION, 'all');
	wp_enqueue_style('custom', get_stylesheet_directory_uri() . '/custom.css' , array('astra-theme-css'), CHILD_THEME_ASTRA_CHILD_VERSION, 'all' );
}

add_action('wp_enqueue_scripts', 'child_enqueue_styles', 15);

// Portfolio Custom Post Type
function Portfolio_init()
{
	// set up Portfolio labels
	$labels = array(
		'name' => 'Portfolios',
		'singular_name' => 'Portfolio',
		'add_new' => 'Add New Portfolio',
		'add_new_item' => 'Add New Portfolio',
		'edit_item' => 'Edit Portfolio',
		'new_item' => 'New Portfolio',
		'all_items' => 'All Portfolios',
		'view_item' => 'View Portfolio',
		'not_found' =>  'No Portfolios Found',
		'parent_item_colon' => '',
		'menu_name' => 'Portfolios',
	);

	// register post type
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'show_ui' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'rewrite' => array('slug' => 'portfolio'),
		'query_var' => true,
		'menu_icon' => 'dashicons-randomize',
		'supports' => array(
			'title',
			'editor',
			'revisions',
			'thumbnail',
			'author',
			'page-attributes'
		)
	);
	register_post_type('Portfolio', $args);
	// register taxonomy
	register_taxonomy(
		'portfolio_category', 'portfolio', 
		array(
			'hierarchical' => true, 
			'label' => 'Project Categories', 
			'query_var' => true, 
			'rewrite' => array('slug' => 'portfolio-category')
			)
		);
}

add_action('init', 'Portfolio_init');
add_post_type_support('Portfolio', 'thumbnail');

add_shortcode('foobar', 'foobar_func');
function foobar_func($atts)
{
	global $post;
	$output = '';
	$args = array(
		'post_type' => 'portfolio',
		'orderby' => 'title',
		'order' => 'ASC',
		'posts_per_page' => 3,

	);
	$fe_query = new WP_Query($args);
	if ($fe_query->have_posts()) {
		$output .= '<div class="archived-posts">';
		while ($fe_query->have_posts()) {
			$fe_query->the_post();

			$title = get_the_title();
			$link = get_the_permalink();
			$image = get_the_post_thumbnail_url();

			$output .= '<div class="archive-item"><div class="top-section">
                     <div class="portfolio-thumbnail">
                        <a href="' . $link . '"><img src="' . $image . '"></a>
                     </div>
                  </div>
               <div class="bottom-section">
                  <div class="portfolio-title">
                     <a href="' . $link . '"><h3>' . $title . '</h3>
                     </a>
                  </div>
                  
                  <div class="read-more">
                        <a href="' . $link . '">Read More <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048"><path d="M6.125 1088h1797.89l-402.976 403 89.994 90L2048 1024l-556.966-557-89.994 90 402.976 403H6.125v128z"></path></svg></a>
                  </div>
               </div>
            </div>';
		}
		$output .= '</div>';
	} else {
		$output .= '<div class="fe-query-results-shortcode-output-none">No      results were found</div>';
	}

	wp_reset_postdata();
	return $output;
}
