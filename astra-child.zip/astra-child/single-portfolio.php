<?php

get_header();
?>
<?php /* The loop */ ?>
<?php while (have_posts()) : the_post(); ?>
   <div class="main-post-div">
      <div class="single-page-post-heading" style="background-image:url(<?php echo get_the_post_thumbnail_url($post->ID) ?>);">
         <h1><?php the_title(); ?></h1>
         <div class="post-meta">
            <div class="date">
               <strong>Published Date: </strong><?php echo esc_attr(get_post_meta(get_the_ID(), 'hcf_published_date', true)); ?>
            </div>
            <div class="category">
               <?php
               $terms = get_the_terms($post->ID, 'portfolio_category');
               if ($terms && !is_wp_error($terms)) {
                  foreach ($terms as $term) {
                     $term_link = get_term_link($term);
                     if (!is_wp_error($term_link)) {
                        echo '<a href="' . esc_url($term_link) . '">' . esc_html($term->name) . '</a>';
                     }
                  }
               }
               ?>
            </div>
         </div>
      </div>
      <div class="content-here">
         <?php the_content();  ?>
      </div>
      <div class="comment-section-here" <?php //comments_template(); 
                                          ?> </div>
      </div>

   <?php endwhile; ?>

   <?php
   get_footer();
   ?>